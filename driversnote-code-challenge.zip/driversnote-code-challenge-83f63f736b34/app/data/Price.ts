export const getTotalPrice = (beacons: number, singlePrice: number) =>
  beacons * singlePrice;
