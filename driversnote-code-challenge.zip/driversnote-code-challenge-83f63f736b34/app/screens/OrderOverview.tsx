import React, { useState } from 'react';
import { Alert, View } from 'react-native';
import { Text, Button, Overlay } from 'react-native-elements';
import { NavigationProps } from '../index';

const OrderOverview = (props: NavigationProps) => {
  const [isVisible, setVisible] = useState(false);

  return (
    <View style={{ flex: 1, justifyContent: 'center' }}>
      <View
        style={{
          height: '50%',
          alignItems: 'center',
          justifyContent: 'space-around',
        }}>
        <Text h2 style={{ color: '#27AAE1' }}>
          Order Overview
        </Text>
        <Text style={{ fontSize: 18, fontWeight: 'bold' }}>
          Ordered iBeacons: {props.route.params?.getOrder().beacons}
        </Text>
        <Text style={{ fontSize: 18, fontWeight: 'bold' }}>
          Full Price: {props.route.params?.getOrder().price}
        </Text>
        <Text h4>Delivery Address</Text>
        <Text style={{ fontSize: 17, fontWeight: 'bold' }}>
          {props.route.params?.getDeliveryAddress().name}
        </Text>
        <Text style={{ fontSize: 17, fontWeight: 'bold' }}>
          {props.route.params?.getDeliveryAddress().address},&nbsp;
          {props.route.params?.getDeliveryAddress().postalCode}
        </Text>
        <Text style={{ fontSize: 17, fontWeight: 'bold' }}>
          {props.route.params?.getDeliveryAddress().city},&nbsp;
          {props.route.params?.getDeliveryAddress().country}
        </Text>
        <Button
          title="Confirm and send the order"
          type="outline"
          style={{ width: '90%' }}
          onPress={() => {
            Alert.alert(
              'Order completed! 📦🚚',
              'You can now go back to the "select user" screen and start over.',
              [
                {
                  text: 'Go back',
                  onPress: () => props.navigation.navigate('Users'),
                },
              ],
            );
          }}
        />
        <Overlay
          isVisible={isVisible}
          onBackdropPress={() => setVisible(false)}>
          <Text h3 style={{ color: '#27AAE1' }}>
            Order completed! 📦🚚
          </Text>
        </Overlay>
      </View>
    </View>
  );
};
export default OrderOverview;
