import React from 'react';
import { View, Text } from 'react-native';
import { Button } from 'react-native-elements';
import { User } from '../data/Users';
import { getTotalPrice } from '../data/Price';
import { NavigationProps } from '../index';

// TODO: Change the price to be fetched dynamically. Imagine that we are running an A/B test to
// expose users to different prices depending on country. To get the correct price, two pieces of
// data must be queried:
// 1. The "user_experiments" endpoint reveals which variant of the "beacon_price" experiment the
//    user has been assigned.
// 2. The "beacon_price" endpoint reveals the price of an iBeacon for each country / experiment
//    variant combination.

// user_experiments endpoint: https://6548fde7dd8ebcd4ab240284.mockapi.io/user_experiments/{user_id}
// beacon_price endpoint: https://633ab21ae02b9b64c6151a44.mockapi.io/api/v2/BeaconPrice

const pricePerBeacon = 30;
const minBeaconsForDiscount = 5;
const discountPercent = 0.15;

const Beacons = (props: NavigationProps) => {
  const user: User = props.route.params?.getUser();
  const price = getTotalPrice(1, pricePerBeacon);

  return (
    <View style={{ flex: 1, justifyContent: 'center' }}>
      <View
        style={{
          height: '50%',
          alignItems: 'center',
          justifyContent: 'space-around',
        }}>
        <View
          style={{
            height: 100,
            alignItems: 'center',
            justifyContent: 'space-around',
          }}>
          <Text style={{ fontSize: 16, color: '#000' }}>1 iBeacon</Text>
          <Text style={{ fontSize: 16, color: '#000' }}>
            Price: {price} USD
          </Text>
        </View>
        <Button
          title="Buy iBeacon"
          type="outline"
          style={{ width: 200 }}
          onPress={() => {
            props.route.params?.setOrder({
              beacons: 1,
              discount: 0,
              price: price,
            });
            props.navigation.navigate('Delivery');
          }}
        />
      </View>
    </View>
  );
};

export default Beacons;
